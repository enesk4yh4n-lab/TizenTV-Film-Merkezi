// Film Merkezi: narrow HTTPS fallback for legacy Samsung TVs.
// Pepper supplies asynchronous TCP; pinned Mbed TLS validates bundled public CAs.
#include <map>
#include <string>
#include <cstring>
#include <cstdio>
#include <sys/time.h>
#include <nacl/nacl_random.h>
#include "mbedtls/ssl.h"
#include "mbedtls/x509_crt.h"
#include "mbedtls/platform_util.h"
#include "ppapi/c/pp_errors.h"
#include "ppapi/cpp/completion_callback.h"
#include "ppapi/cpp/core.h"
#include "ppapi/cpp/instance.h"
#include "ppapi/cpp/module.h"
#include "ppapi/cpp/private/host_resolver_private.h"
#include "ppapi/cpp/private/tcp_socket_private.h"
#include "ppapi/cpp/var_dictionary.h"
#include "ppapi/utility/completion_callback_factory.h"
#include "http-response.h"
#include "ca-bundle.h"
#include "network-policy.h"
#include "repository-policy.h"
#include "ppapi/cpp/var_array_buffer.h"
#include "ppapi/cpp/private/net_address_private.h"

extern "C" mbedtls_ms_time_t mbedtls_ms_time(void) {
  struct timeval value;
  if (gettimeofday(&value, NULL)) return 0;
  return static_cast<mbedtls_ms_time_t>(value.tv_sec) * 1000 + value.tv_usec / 1000;
}

namespace {
bool Url(const std::string& text, std::string* host, std::string* target) {
  if (text.size() > 4096 || text.compare(0, 8, "https://") || (text.find_first_of("\r\n\t #\\") != std::string::npos || text.find('\0') != std::string::npos)) return false;
  size_t slash = text.find('/', 8); if (slash == std::string::npos) return false;
  *host = text.substr(8, slash - 8); *target = text.substr(slash);
#ifdef FILM_HTTP_QA
  if (*host == "self-signed.badssl.com" || *host == "wrong.host.badssl.com" || *host == "test-streams.mux.dev") return true;
#endif
  return film_policy::Host(*host);
}
class Instance;
class Job {
 public:
  Job(Instance* owner, int id, const std::string& host, const std::string& target, const std::string& referer, bool binary, size_t limit, const std::string& extra, const std::string& method, const std::string& body);
  ~Job() { callbacks_.CancelAll(); socket_.Disconnect(); mbedtls_ssl_free(&ssl_); mbedtls_ssl_config_free(&config_); mbedtls_x509_crt_free(&ca_); }
  void Start();
  bool Binary() const { return binary_; }
  size_t Limit() const { return limit_; }
 private:
  void Resolved(int32_t result);
  void Connected(int32_t result);
  void Written(int32_t result);
  void Read(int32_t result);
  void Pump(int32_t unused);
  void WriteEncrypted(int32_t unused);
  void ReadEncrypted(int32_t unused);
  static int Send(void* context, const unsigned char* data, size_t size);
  static int Receive(void* context, unsigned char* data, size_t size);
  static int Random(void*, unsigned char* data, size_t size);
  void Timeout(int32_t);
  void Fail(const std::string& stage, int32_t code);
  void Finish();
  bool binary_; size_t limit_; size_t progress_;
  Instance* owner_; int id_; std::string host_, request_, raw_; size_t written_;
  char buffer_[16384]; unsigned char plain_[16384];
  int tls_state_, transport_error_; bool write_pending_, write_ready_, read_pending_, eof_;
  std::string outgoing_, incoming_; size_t outgoing_at_, incoming_at_;
  mbedtls_ssl_context ssl_; mbedtls_ssl_config config_; mbedtls_x509_crt ca_;
  pp::TCPSocketPrivate socket_; pp::HostResolverPrivate resolver_;
  pp::CompletionCallbackFactory<Job> callbacks_;
};
class Instance : public pp::Instance {
 public:
  explicit Instance(PP_Instance id) : pp::Instance(id), configured_(false) {}
  ~Instance() { while (!jobs_.empty()) Cancel(jobs_.begin()->first); }
  bool Init(uint32_t, const char*[], const char*[]) {
    pp::VarDictionary message; message.Set("kind", "ready"); message.Set("protocol", 1);
    message.Set("tls", pp::TCPSocketPrivate::IsAvailable()); message.Set("policy", 1); message.Set("binary", true); message.Set("repositoryTrust", 1); message.Set("originPatterns", 1);
    message.Set("tlsEngine", "MbedTLS 3.6.7");
    message.Set("ipv4", pp::HostResolverPrivate::IsAvailable()); PostMessage(message); return true;
  }
  void HandleMessage(const pp::Var& value) {
    if (!value.is_dictionary()) return;
    pp::VarDictionary message(value); pp::Var id_value = message.Get("id"), kind_value = message.Get("kind");
    if (!id_value.is_int() || id_value.AsInt() <= 0 || !kind_value.is_string()) return;
    int id = id_value.AsInt(); const std::string kind = kind_value.AsString();
    if (kind == "cancel") { Cancel(id); return; }
    if (kind == "configure") { pp::Var policy=message.Get("policy"),signature=message.Get("signature"); if(configured_||!policy.is_string()||!signature.is_string()||!film_policy::Verify(policy.AsString(),signature.AsString(),&origins_)){Reply(id,"policy",-1,NULL);return;}configured_=true;Reply(id,"policy",0,NULL);return; }
    if(kind=="repository"){pp::Var rid=message.Get("repositoryId"),url=message.Get("url"),key=message.Get("publicKey");bool ok=rid.is_string()&&url.is_string()&&key.is_string()&&repositories_.Register(rid.AsString(),url.AsString(),key.AsString());Reply(id,"repository",ok?0:-1,NULL);return;}
    if(kind=="repository-policy"){pp::Var rid=message.Get("repositoryId"),pid=message.Get("pluginId"),text=message.Get("policy"),sig=message.Get("signature");bool ok=rid.is_string()&&pid.is_string()&&text.is_string()&&sig.is_string()&&repositories_.Policy(rid.AsString(),pid.AsString(),text.AsString(),sig.AsString(),origins_);Reply(id,"policy",ok?0:-1,NULL);return;}
    if(kind=="repository-remove"){pp::Var rid=message.Get("repositoryId");if(!rid.is_string()){Reply(id,"repository",-1,NULL);return;}repositories_.Remove(rid.AsString());Reply(id,"repository",0,NULL);return;}
    if (kind != "request" || jobs_.count(id)) return;
    pp::Var url = message.Get("url"), ref = message.Get("referer"); std::string host, target;
    if (!url.is_string() || !ref.is_string() || !Url(url.AsString(), &host, &target)) { Reply(id,"validation",-1,NULL);return; }
    const std::string update_root="/enesk4yh4n-lab/TizenTV-Film-Merkezi/main/github-eklenti/";
    bool github=host=="raw.githubusercontent.com"&&target.compare(0,update_root.size(),update_root)==0&&target.find("..") == std::string::npos&&target.find_first_of("%\\")==std::string::npos;
    if(!github&&!film_policy::Allowed(host,origins_)&&!repositories_.Allowed(host)&&!repositories_.Request(host,target)){Reply(id,"validation",-1,NULL);return;}
    std::string referer=ref.AsString(),rh,rt;
    if(!referer.empty()&&(!Url(referer,&rh,&rt)||(!film_policy::Allowed(rh,origins_)&&!repositories_.Allowed(rh)&&!repositories_.Request(rh,rt)))){Reply(id,"validation",-1,NULL);return;}
    pp::Var binaryVar=message.Get("binary"),limitVar=message.Get("byteLimit"),methodVar=message.Get("method"),bodyVar=message.Get("body");bool binary=binaryVar.is_bool()&&binaryVar.AsBool();size_t limit=limitVar.is_int()&&limitVar.AsInt()>0?static_cast<size_t>(limitVar.AsInt()):(binary?8*1024*1024:2*1024*1024);
    if(limit>(binary?12*1024*1024:2*1024*1024)){Reply(id,"validation",-1,NULL);return;}std::string method=methodVar.is_string()?methodVar.AsString():"GET",body=bodyVar.is_string()?bodyVar.AsString():"";
    if((method!="GET"&&method!="POST")||body.size()>262144||(method=="GET"&&!body.empty())){Reply(id,"validation",-1,NULL);return;}
    std::string extra;const char* headerNames[]={"Range","Origin","Content-Type","X-Requested-With"};pp::Var hv=message.Get("headers");if(hv.is_dictionary()){pp::VarDictionary headers(hv);for(size_t i=0;i<4;i++){pp::Var v=headers.Get(headerNames[i]);if(!v.is_undefined()){if(!v.is_string()){Reply(id,"validation",-1,NULL);return;}std::string value=v.AsString();if(value.size()>2048||value.find_first_of("\r\n")!=std::string::npos){Reply(id,"validation",-1,NULL);return;}if(i==1){std::string h;if(!film_policy::Origin(value,&h)||(!film_policy::Allowed(h,origins_)&&!repositories_.Allowed(h))){Reply(id,"validation",-1,NULL);return;}}extra+=std::string(headerNames[i])+": "+value+"\r\n";}}}
    if(!pp::TCPSocketPrivate::IsAvailable()||jobs_.size()>=2){Reply(id,"unavailable",PP_ERROR_NOINTERFACE,NULL);return;}
    jobs_[id]=new Job(this,id,host,target,referer,binary,limit,extra,method,body);jobs_[id]->Start();
  }
  void Progress(int id,size_t loaded){pp::VarDictionary m;m.Set("kind","progress");m.Set("id",id);m.Set("loaded",static_cast<int>(loaded));PostMessage(m);}
  void Reply(int id, const std::string& stage, int code, const film_http::Response* response) {
    pp::VarDictionary message; message.Set("kind", "result"); message.Set("id", id);
    message.Set("stage", stage); message.Set("code", code);
    Job* job=jobs_.count(id)?jobs_[id]:NULL;
    if(stage=="size"){message.Set("byteLimitExceeded",true);message.Set("byteLimit",static_cast<int>(job?job->Limit():0));}
    if(response){message.Set("status",response->status);message.Set("location",response->location);message.Set("error",response->error);message.Set("mimeType",response->mimeType);message.Set("contentRange",response->contentRange);if(job&&job->Binary()){pp::VarArrayBuffer data(static_cast<uint32_t>(response->body.size()));void* bytes=data.Map();if(bytes&&!response->body.empty())std::memcpy(bytes,response->body.data(),response->body.size());data.Unmap();message.Set("data",data);}else message.Set("body",response->body);}
    PostMessage(message); Cancel(id);
  }
 private:
  void Cancel(int id) { std::map<int, Job*>::iterator found = jobs_.find(id); if (found == jobs_.end()) return; Job* job = found->second; jobs_.erase(found); delete job; }
  std::map<int, Job*> jobs_;
  std::set<std::string> origins_; bool configured_; film_repositories::Registry repositories_;
};
Job::Job(Instance* owner, int id, const std::string& host, const std::string& target, const std::string& referer, bool binary, size_t limit, const std::string& extra, const std::string& method, const std::string& body)
    : binary_(binary), limit_(limit), progress_(0), owner_(owner), id_(id), host_(host), written_(0), tls_state_(0), transport_error_(0), write_pending_(false), write_ready_(false), read_pending_(false), eof_(false), outgoing_at_(0), incoming_at_(0), socket_(owner), resolver_(owner), callbacks_(this) {
  mbedtls_ssl_init(&ssl_); mbedtls_ssl_config_init(&config_); mbedtls_x509_crt_init(&ca_);
  request_ = method + " " + target + " HTTP/1.1\r\nHost: " + host + "\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n";
  if (!referer.empty()) request_ += "Referer: " + referer + "\r\n";
  request_ += extra; if(method=="POST"){char length[32];std::sprintf(length,"%u",static_cast<unsigned>(body.size()));request_ += std::string("Content-Length: ")+length+"\r\n";} request_ += "\r\n"+body;
}
void Job::Start() {
  pp::Module::Get()->core()->CallOnMainThread(30000, callbacks_.NewCallback(&Job::Timeout));
  if (pp::HostResolverPrivate::IsAvailable()) {
    PP_HostResolver_Private_Hint hint = {PP_NETADDRESSFAMILY_PRIVATE_IPV4, 0};
    int32_t result = resolver_.Resolve(host_, 443, hint, callbacks_.NewCallback(&Job::Resolved));
    if (result != PP_OK_COMPLETIONPENDING) Resolved(result);
  } else { Fail("unavailable",PP_ERROR_NOINTERFACE); }
}
void Job::Resolved(int32_t result) {
  if (result != PP_OK) { Fail("dns", result); return; }
  PP_NetAddress_Private address;
  if (!resolver_.GetNetAddress(0, &address)) { Fail("dns", PP_ERROR_NAME_NOT_RESOLVED); return; }
  unsigned char ip[4];if(pp::NetAddressPrivate::GetFamily(address)!=PP_NETADDRESSFAMILY_PRIVATE_IPV4||!pp::NetAddressPrivate::GetAddress(address,ip,4)||!film_policy::PublicIPv4(ip)){Fail("validation",-1);return;}
  result = socket_.ConnectWithNetAddress(&address, callbacks_.NewCallback(&Job::Connected));
  if (result != PP_OK_COMPLETIONPENDING) Connected(result);
}
void Job::Connected(int32_t result) {
  if (result != PP_OK) { Fail("connect", result); return; }
  result = mbedtls_x509_crt_parse(&ca_, kCaBundle, sizeof(kCaBundle));
  if (result < 0) { Fail("ca", result); return; }
  result = mbedtls_ssl_config_defaults(&config_, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
  if (result) { Fail("tls-config", result); return; }
  mbedtls_ssl_conf_authmode(&config_, MBEDTLS_SSL_VERIFY_REQUIRED);
  mbedtls_ssl_conf_ca_chain(&config_, &ca_, NULL);
  mbedtls_ssl_conf_rng(&config_, &Job::Random, NULL);
  result = mbedtls_ssl_setup(&ssl_, &config_);
  if (!result) result = mbedtls_ssl_set_hostname(&ssl_, host_.c_str());
  if (result) { Fail("tls-config", result); return; }
  mbedtls_ssl_set_bio(&ssl_, this, &Job::Send, &Job::Receive, NULL);
  Pump(0);
}
int Job::Random(void*, unsigned char* data, size_t size) {
  size_t written = 0;
  return !nacl_secure_random(data, size, &written) && written == size ? 0 : MBEDTLS_ERR_SSL_INTERNAL_ERROR;
}
int Job::Send(void* context, const unsigned char* data, size_t size) {
  Job* job = static_cast<Job*>(context);
  if (job->transport_error_) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
  if (job->write_ready_) {
    if (size != job->outgoing_.size() || std::memcmp(data, job->outgoing_.data(), size)) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
    job->write_ready_ = false; job->outgoing_.clear(); return static_cast<int>(size);
  }
  if (!job->write_pending_) {
    job->outgoing_.assign(reinterpret_cast<const char*>(data), size); job->outgoing_at_ = 0; job->write_pending_ = true;
    pp::Module::Get()->core()->CallOnMainThread(0, job->callbacks_.NewCallback(&Job::WriteEncrypted));
  }
  return MBEDTLS_ERR_SSL_WANT_WRITE;
}
int Job::Receive(void* context, unsigned char* data, size_t size) {
  Job* job = static_cast<Job*>(context);
  if (job->transport_error_) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
  if (job->incoming_at_ < job->incoming_.size()) {
    size_t count = std::min(size, job->incoming_.size() - job->incoming_at_);
    std::memcpy(data, job->incoming_.data() + job->incoming_at_, count); job->incoming_at_ += count;
    if (job->incoming_at_ == job->incoming_.size()) { job->incoming_.clear(); job->incoming_at_ = 0; }
    return static_cast<int>(count);
  }
  if (job->eof_) return 0;
  if (!job->read_pending_) { job->read_pending_ = true; pp::Module::Get()->core()->CallOnMainThread(0, job->callbacks_.NewCallback(&Job::ReadEncrypted)); }
  return MBEDTLS_ERR_SSL_WANT_READ;
}
void Job::WriteEncrypted(int32_t) {
  int32_t result = socket_.Write(outgoing_.data() + outgoing_at_, outgoing_.size() - outgoing_at_, callbacks_.NewCallback(&Job::Written));
  if (result != PP_OK_COMPLETIONPENDING) Written(result);
}
void Job::Written(int32_t result) {
  if (result <= 0) { transport_error_ = result ? result : -1; write_pending_ = false; }
  else {
    outgoing_at_ += result;
    if (outgoing_at_ < outgoing_.size()) { WriteEncrypted(0); return; }
    write_pending_ = false; write_ready_ = true;
  }
  pp::Module::Get()->core()->CallOnMainThread(0, callbacks_.NewCallback(&Job::Pump));
}
void Job::ReadEncrypted(int32_t) {
  int32_t result = socket_.Read(buffer_, sizeof(buffer_), callbacks_.NewCallback(&Job::Read));
  if (result != PP_OK_COMPLETIONPENDING) Read(result);
}
void Job::Read(int32_t result) {
  read_pending_ = false;
  if (result < 0) transport_error_ = result;
  else if (!result) eof_ = true;
  else incoming_.append(buffer_, result);
  pp::Module::Get()->core()->CallOnMainThread(0, callbacks_.NewCallback(&Job::Pump));
}
void Job::Pump(int32_t) {
  for (;;) {
    int result;
    if (!tls_state_) {
      result = mbedtls_ssl_handshake(&ssl_);
      if (result == MBEDTLS_ERR_SSL_WANT_READ || result == MBEDTLS_ERR_SSL_WANT_WRITE) return;
      if (result || mbedtls_ssl_get_verify_result(&ssl_)) { Fail("tls", result ? result : MBEDTLS_ERR_X509_CERT_VERIFY_FAILED); return; }
      tls_state_ = 1;
    }
    if (tls_state_ == 1) {
      if (written_ == request_.size()) { tls_state_ = 2; continue; }
      result = mbedtls_ssl_write(&ssl_, reinterpret_cast<const unsigned char*>(request_.data() + written_), request_.size() - written_);
      if (result == MBEDTLS_ERR_SSL_WANT_READ || result == MBEDTLS_ERR_SSL_WANT_WRITE) return;
      if (result <= 0) { Fail("write", result); return; }
      written_ += result; continue;
    }
    result = mbedtls_ssl_read(&ssl_, plain_, sizeof(plain_));
    if (result == MBEDTLS_ERR_SSL_WANT_READ || result == MBEDTLS_ERR_SSL_WANT_WRITE) return;
    if (!result || result == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY) { Finish(); return; }
    if (result < 0) { Fail("read", result); return; }
    if (raw_.size() + result > limit_ + 65536) { Fail("size", PP_ERROR_NOMEMORY); return; }
    raw_.append(reinterpret_cast<const char*>(plain_), result);
    size_t split=raw_.find("\r\n\r\n");if(split!=std::string::npos){size_t loaded=raw_.size()-split-4;if(loaded&&(!progress_||loaded-progress_>=131072)){progress_=loaded;owner_->Progress(id_,loaded);}}
  }
}
void Job::Timeout(int32_t) { Fail("timeout", PP_ERROR_TIMEDOUT); }
void Job::Fail(const std::string& stage, int32_t code) { owner_->Reply(id_, stage, code, NULL); }
void Job::Finish() { film_http::Response response = film_http::Parse(raw_,limit_); owner_->Reply(id_, response.tooLarge ? "size" : response.error.empty() ? "http" : "parse", response.error.empty() ? 0 : -1, &response); }
class Module : public pp::Module { public: pp::Instance* CreateInstance(PP_Instance id) { return new Instance(id); } };
}  // namespace
namespace pp { Module* CreateModule() { return new ::Module(); } }
