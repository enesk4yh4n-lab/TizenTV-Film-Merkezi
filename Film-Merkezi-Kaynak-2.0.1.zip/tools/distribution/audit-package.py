"""Verify signed SDK output and produce an exactly matching unsigned public WGT."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import sys,json,hashlib,re,base64,shutil,os,xml.etree.ElementTree as ET
from urllib.parse import unquote
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
root=Path(__file__).resolve().parents[2]; app=root/'uygulama'; artifact=Path(sys.argv[1]); names=set(json.loads((root/'tools/distribution/package-files.json').read_text())); signatures={'author-signature.xml','signature1.xml'}; ns={'ds':'http://www.w3.org/2000/09/xmldsig#'}
sha=lambda b:hashlib.sha256(b).hexdigest()
with ZipFile(artifact) as z:
 assert {n for n in z.namelist() if not n.endswith('/')}==names|signatures
 def semantic(b):
  e=ET.fromstring(b);return e.tag,sorted(e.attrib.items()),sorted((c.tag,sorted(c.attrib.items()),(c.text or '').strip()) for c in e)
 assert semantic(z.read('config.xml'))==semantic((app/'config.xml').read_bytes())
 # Retain the SDK-normalized bytes as the canonical config, only after equality.
 (app/'config.xml').write_bytes(z.read('config.xml'))
 for n in names: assert z.read(n)==(app/n).read_bytes(),n
 count=0
 for n in signatures:
  raw=z.read(n).decode();doc=ET.fromstring(raw);info=doc.find('ds:SignedInfo',ns);cert=x509.load_der_x509_certificate(base64.b64decode(doc.find('.//ds:X509Certificate',ns).text))
  fragment=re.search(r'<SignedInfo\b[^>]*>[\s\S]*?</SignedInfo>',raw)[0]
  if 'xmlns=' not in fragment.split('>')[0]:fragment=fragment.replace('<SignedInfo>','<SignedInfo xmlns="'+ns['ds']+'">',1)
  alg=info.find('ds:SignatureMethod',ns).get('Algorithm').split('#')[-1]
  cert.public_key().verify(base64.b64decode(doc.findtext('ds:SignatureValue',namespaces=ns)),ET.canonicalize(xml_data=fragment).encode(),padding.PKCS1v15(),hashes.SHA512() if alg=='rsa-sha512' else hashes.SHA256())
  for ref in info.findall('ds:Reference',ns):
   uri=unquote(ref.get('URI'));alg=ref.find('ds:DigestMethod',ns).get('Algorithm').split('#')[-1]
   if uri.startswith('#'):
    fragment=re.search(r'<Object\b[^>]*\bId="'+re.escape(uri[1:])+r'"[^>]*>[\s\S]*?</Object>',raw)[0]
    if 'xmlns=' not in fragment.split('>')[0]:fragment=fragment.replace('<Object','<Object xmlns="'+ns['ds']+'"',1)
    value=fragment.encode()
   else:value=z.read(uri)
   assert base64.b64encode(hashlib.new(alg,value).digest()).decode()==''.join(ref.findtext('ds:DigestValue',namespaces=ns).split()),uri
   count+=1
version=ET.parse(app/'config.xml').getroot().get('version');signed=root/f'Film-Merkezi-TV-{version}.wgt';public=root/f'Film-Merkezi-TV-{version}-public.wgt'
shutil.copy2(artifact,signed);shutil.copy2(signed,root/'ChainProbe.wgt')
with ZipFile(public,'w',ZIP_DEFLATED) as z:
 for n in sorted(names):z.write(app/n,n)
report={'passed':True,'signatureReferences':count,'packages':[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'files':len(names)+(2 if p==signed else 0)} for p in [signed,public]],'githubPublished':False}
out=Path(os.environ.get('FILM_RELEASE_WORKDIR',str(root/'tools/test-results/cleanup181')));out.mkdir(parents=True,exist_ok=True)
(out/'package.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
