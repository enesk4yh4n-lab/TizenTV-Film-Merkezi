param([switch]$Draft,[string]$Profile='FilmMerkeziEmulator',[string]$WorkName='community190')
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
if($WorkName -notmatch '^[a-zA-Z0-9-]+$'){throw 'Invalid release workspace name'}
$env:FILM_RELEASE_WORKDIR=Join-Path $taskRoot "tools/test-results/$WorkName"
if($Draft){& node (Join-Path $PSScriptRoot 'prepare.cjs') --draft}else{& node (Join-Path $PSScriptRoot 'prepare.cjs')}
if($LASTEXITCODE -ne 0){throw 'Canonical preparation failed'}
$taskStage=Join-Path $env:FILM_RELEASE_WORKDIR 'sdk-stage'
$taskNames=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'package-files.json') -Raw | ConvertFrom-Json
if(Test-Path -LiteralPath $taskStage){
 $taskResolved=[IO.Path]::GetFullPath($taskStage)
 $taskParent=[IO.Path]::GetFullPath($env:FILM_RELEASE_WORKDIR)
 if((Split-Path -Parent $taskResolved) -ne $taskParent -or (Split-Path -Leaf $taskResolved) -ne 'sdk-stage'){throw 'Stage cleanup path check failed'}
 Remove-Item -LiteralPath $taskResolved -Recurse -Force
}
foreach($taskName in @($taskNames)+@('tizen_web_project.yaml')){
 $taskDestination=Join-Path $taskStage $taskName
 [IO.Directory]::CreateDirectory((Split-Path -Parent $taskDestination)) | Out-Null
 Copy-Item -LiteralPath (Join-Path $taskRoot "uygulama/$taskName") -Destination $taskDestination
}
$taskSdk=([IO.File]::ReadAllText((Join-Path $env:USERPROFILE '.tizen.sdk.path.config'))).Trim()
$taskTz=Join-Path $taskSdk 'tools/tizen-core/tz.exe'
& $taskTz build -w $taskStage -b Debug -s $Profile
if($LASTEXITCODE -ne 0){throw 'SDK build failed'}
& $taskTz pack -w $taskStage -s $Profile
if($LASTEXITCODE -ne 0){throw 'SDK signing failed'}
$taskArtifact=Join-Path $env:FILM_RELEASE_WORKDIR 'sdk-output/Debug/sdk-stage.wgt'
if(!(Test-Path -LiteralPath $taskArtifact)){throw 'SDK output missing'}
& python (Join-Path $PSScriptRoot 'audit-package.py') $taskArtifact
if($LASTEXITCODE -ne 0){throw 'Package audit failed'}
