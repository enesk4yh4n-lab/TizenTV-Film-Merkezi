'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),acorn=require('acorn'),crypto=require('node:crypto'),cp=require('node:child_process');
const root=path.resolve(__dirname,'../..'),app=path.join(root,'uygulama'),names=JSON.parse(fs.readFileSync(path.join(__dirname,'package-files.json'))),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
let syntax=0,es5=0;
for(const n of names){assert(!/^(?:tools|saglayicilar|siteler|compat-media)\/|^bundled\/sites\//.test(n),n);assert(!/author-signature|signature1\.xml/.test(n));const p=path.join(app,n);assert(fs.existsSync(p),n);if(n.endsWith('.js')){cp.execFileSync(process.execPath,['--check',p]);syntax++;if(!/^vendor\/|^cozumleyiciler\/youtube\//.test(n)){acorn.parse(fs.readFileSync(p,'utf8'),{ecmaVersion:5});es5++;}}}
const raw=fs.readFileSync(path.join(app,'bundled/manifest.json')),m=JSON.parse(raw),cfg=JSON.parse(fs.readFileSync(path.join(app,'bootstrap/config.js'),'utf8').replace(/^window.FilmUpdateConfig = /,'').replace(/;\s*$/,'')),key=crypto.createPublicKey({key:Buffer.from(cfg.publicKey,'base64'),format:'der',type:'spki'});
assert(crypto.verify('sha256',raw,key,Buffer.from(fs.readFileSync(path.join(app,'bundled/manifest.sig'),'utf8').trim(),'base64')));
for(const f of m.files){const b=fs.readFileSync(path.join(app,f.path));assert.equal(b.length,f.size,f.path);assert.equal(sha(b),f.sha256,f.path);assert(names.includes(f.path));}
for(const n of m.scripts.concat(m.styles,m.shell,m.sites))assert(names.includes(n),n);
const xml=fs.readFileSync(path.join(app,'config.xml'),'utf8');assert(!xml.includes('@'));assert(xml.includes('id="FilmMerkez.FilmMerkezi"'));assert.equal(/<widget\b[^>]*version="([^"]+)"/.exec(xml)[1],cfg.appVersion);
const framePath=path.join(app,'cozumleyiciler/youtube/api-frame.html');
if(fs.existsSync(framePath)){const frame=/<script>([\s\S]*?)<\/script>/.exec(fs.readFileSync(framePath,'utf8'))[1];assert(xml.includes('sha256-'+crypto.createHash('sha256').update(frame).digest('base64')));}
else assert(xml.includes("'sha256-fC+VEVSj+Rqc3UVIU1lmAqo+N+mXuYHMS4aU8uMF15s='"),'Existing CSP hash must stay unchanged');
const baseline=path.join(root,'tools/test-results/cleanup181/before.json'),before=fs.existsSync(baseline)?JSON.parse(fs.readFileSync(baseline)):{protected:{}};
for(const[n,h]of Object.entries(before.protected)){const relative=n.replace(/^uygulama\//,'');if(names.includes(relative))assert.equal(sha(fs.readFileSync(path.join(root,n))),h,n);}
const html=fs.readFileSync(path.join(app,'index.html'),'utf8');for(const v of html.matchAll(/(?:src|href)="([^"]+)"/g))assert(v[1].startsWith('$WEBAPIS')||names.includes(v[1]),v[1]);
const report={passed:true,files:names.length,nodeSyntax:syntax,es5,component:m.version,application:cfg.appVersion,cspHash:true,unchangedVendorAndNotices:Object.keys(before.protected).length};
console.log(JSON.stringify(report));if(process.argv.includes('--report')){fs.mkdirSync(path.join(root,'tools/test-results/cleanup181'),{recursive:true});fs.writeFileSync(path.join(root,'tools/test-results/cleanup181/static.json'),JSON.stringify(report,null,2));}
