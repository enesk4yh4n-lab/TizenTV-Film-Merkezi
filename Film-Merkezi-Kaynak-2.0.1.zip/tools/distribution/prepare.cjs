'use strict';
// Canonical application -> signed offline core + local update channel. Never publishes.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'../..'),app=path.join(root,'uygulama'),out=process.env.FILM_RELEASE_WORKDIR||path.join(root,'tools/test-results/cleanup181');
const read=n=>fs.readFileSync(path.join(app,n)),write=(n,b)=>{fs.mkdirSync(path.dirname(n),{recursive:true});fs.writeFileSync(n,b);},hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const cfg=JSON.parse(read('bootstrap/config.js').toString().replace(/^window.FilmUpdateConfig = /,'').replace(/;\s*$/,'')),version=/<widget[^>]*version="([^"]+)"/.exec(read('config.xml'))[1];
const channelRoot='https://raw.githubusercontent.com/enesk4yh4n-lab/TizenTV-Film-Merkezi/main/',relative=cfg.channel.slice(channelRoot.length);assert(cfg.channel.startsWith(channelRoot)&&/^github-eklenti(?:\/[a-zA-Z0-9_-]+)*$/.test(relative),'Unexpected production channel');const feed=path.join(root,relative);
assert.equal(version,cfg.appVersion);
const key=crypto.createPrivateKey(fs.readFileSync(path.join(os.homedir(),'.film-merkezi-updates/pilot/signing-key.pem'))),publicKey=crypto.createPublicKey(key).export({type:'spki',format:'der'}).toString('base64'),sign=b=>crypto.sign('sha256',Buffer.from(b),key).toString('base64')+'\n';assert.equal(publicKey,cfg.publicKey);
const nativeSource=path.join(root,'kaynak/ortak/ag/native'),native=JSON.parse(fs.readFileSync(path.join(nativeSource,'build-hashes.json')));assert(!native.qa);
for(const [name,info] of Object.entries(native.files)){const b=read('ortak/ag/native/'+name);assert.equal(hash(b),info.sha256,name);assert.equal(b.length,info.size,name);}
for(const [name,digest] of Object.entries(native.inputs)){assert.equal(hash(fs.readFileSync(path.join(nativeSource,name))),digest,name);}
const reporting=JSON.parse(read('ortak/destek/config.json')),origins=reporting.enabled?[new URL(reporting.endpoint).origin]:[];
// The signed core includes optional TMDB metadata; packaging must retain its API access.
if(fs.existsSync(path.join(app,'ortak/katalog/metadata-config.js')))origins.push('https://api.themoviedb.org');
const policy='FILM-MERKEZI-ORIGINS-1\n'+Array.from(new Set(origins)).join('\n')+'\n';
write(path.join(app,'network-policy.txt'),policy);write(path.join(app,'network-policy.signature.txt'),sign(policy));
const m=JSON.parse(fs.readFileSync(path.join(app,'bundled/manifest.json')));
m.version=cfg.componentMinVersion;m.minAppVersion=version;delete m.legacyTextOrigins;
for(const f of m.files){const b=read(f.path);f.size=b.length;f.sha256=hash(b);}
const raw=JSON.stringify(m,null,2)+'\n',signature=sign(raw),versionDir=path.join(feed,'versions',m.version);
if(fs.existsSync(path.join(versionDir,'manifest.json'))){
 const previous=fs.readFileSync(path.join(versionDir,'manifest.json'),'utf8');
 if(previous!==raw){assert(process.argv.includes('--draft'),'Core version already exists; bump version or explicitly rebuild an unpublished draft');const receipt=JSON.parse(fs.readFileSync(path.join(out,'prepare.json')));assert.equal(receipt.manifestSha256,hash(previous));assert.equal(receipt.githubPublished,false);}
}
for(const f of m.files)write(path.join(versionDir,'runtime',f.path),read(f.path));
for(const folder of [path.join(app,'bundled'),versionDir]){write(path.join(folder,'manifest.json'),raw);write(path.join(folder,'manifest.sig'),signature);}
const pointerPath=path.join(feed,'update.json'),old=fs.existsSync(pointerPath)?JSON.parse(fs.readFileSync(pointerPath)):{revision:74};
let publishedRevision=0;
for(const entry of fs.readdirSync(path.join(root,'github-hazirlik'),{withFileTypes:true}).filter(e=>e.isDirectory())){
 const receipt=path.join(root,'github-hazirlik',entry.name,'published.json');
 if(fs.existsSync(receipt)){const value=JSON.parse(fs.readFileSync(receipt));if(value.published&&value.verified&&value.versions&&Number.isInteger(value.versions.coreRevision))publishedRevision=Math.max(publishedRevision,value.versions.coreRevision);}
}
const requestedRevision=Number(process.env.FILM_CORE_REVISION||0);assert(Number.isInteger(requestedRevision)&&requestedRevision>=0);
const p={schemaVersion:1,channel:'stable',revision:Math.max(old.updateVersion===m.version?old.revision:old.revision+1,publishedRevision+1,requestedRevision),updateVersion:m.version,minAppVersion:version,manifest:'versions/'+m.version+'/manifest.json',manifestSha256:hash(raw)},pointer=JSON.stringify(p,null,2)+'\n';
write(pointerPath,pointer);write(path.join(feed,'update.sig'),sign(pointer));
const names=JSON.parse(fs.readFileSync(path.join(__dirname,'package-files.json')));
for(const n of names){assert(fs.existsSync(path.join(app,n)),n);assert(!/^(tools|saglayicilar|siteler|compat-media)\/|^bundled\/sites\//.test(n));}
const yamlPath=path.join(app,'tizen_web_project.yaml'),yaml=fs.readFileSync(yamlPath,'utf8');write(yamlPath,yaml.replace(/^files:\r?\n[\s\S]*?(?=^excludes:)/m,'files:\n'+names.map(n=>'  - '+n).join('\n')+'\n'));
write(path.join(out,'prepare.json'),JSON.stringify({application:version,component:m.version,files:names.length,manifestSha256:hash(raw),native,githubPublished:false},null,2));
console.log(JSON.stringify({application:version,component:m.version,files:names.length,manifestSha256:hash(raw),githubPublished:false}));
