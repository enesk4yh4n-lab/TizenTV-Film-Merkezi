'use strict';
const {fs,path,root,write}=require('./shared.cjs');
const dir=path.join(__dirname,'native'),source=path.join(root,'kaynak/ortak/ag/native');
let cpp=fs.readFileSync(path.join(source,'secure-http.cpp'),'utf8');
const marker='#ifdef FILM_HTTP_QA';
if(!cpp.includes(marker))throw Error('Native source changed');
cpp=cpp.replace(marker,'// The pilot alone can fetch its signed GitHub channel. TLS and hostname validation stay enabled.\n  if (*host == "raw.githubusercontent.com" && target->compare(0, 59, "/enesk4yh4n-lab/TizenTV-Film-Merkezi/main/updates/pilot/") == 0 && target->find("..") == std::string::npos && target->find_first_of("%\\\\") == std::string::npos) return true;\n'+marker);
// Derive the prefix length, rather than depending on a hand-counted literal.
const prefix='/enesk4yh4n-lab/TizenTV-Film-Merkezi/main/updates/pilot/';
cpp=cpp.replace('target->compare(0, 59,','target->compare(0, '+prefix.length+',');
cpp=cpp.replace('(host == "www.ddizi.tel" && !Referrer(ref.AsString()))','(host == "www.ddizi.tel" && !Referrer(ref.AsString())) || (host == "raw.githubusercontent.com" && !ref.AsString().empty())');
write(path.join(dir,'secure-http.cpp'),cpp);
for(const n of fs.readdirSync(source).filter(n=>/\.(h|pem)$/.test(n)))write(path.join(dir,n),fs.readFileSync(path.join(source,n)));
console.log('Prepared isolated pilot TLS source; production native source unchanged.');
