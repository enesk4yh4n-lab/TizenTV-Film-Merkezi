'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),os=require('node:os');
const root=path.resolve(__dirname,'../..'),stage=path.join(root,'tools/test-results/update130/stage'),feed=path.join(root,'updates/pilot');
const keyDir=path.join(os.homedir(),'.film-merkezi-updates/pilot'),keyFile=path.join(keyDir,'signing-key.pem');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
function key(){fs.mkdirSync(keyDir,{recursive:true,mode:0o700});if(!fs.existsSync(keyFile)){const pair=crypto.generateKeyPairSync('rsa',{modulusLength:2048});fs.writeFileSync(keyFile,pair.privateKey.export({type:'pkcs8',format:'pem'}),{mode:0o600,flag:'wx'});}return crypto.createPrivateKey(fs.readFileSync(keyFile));}
function write(file,value){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,value);}
function sign(text,k){return crypto.sign('sha256',Buffer.from(text),k).toString('base64')+'\n';}
module.exports={fs,path,crypto,root,stage,feed,keyDir,keyFile,key,hash,write,sign};
