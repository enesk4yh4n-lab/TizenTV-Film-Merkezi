'use strict';
const {fs,path,root}=require('./shared.cjs'),assert=require('node:assert/strict');
function edit(s,a,b){assert(s.includes(a),'Transport source changed: '+a.slice(0,60));return s.replace(a,b);}
exports.text=()=>{let s=fs.readFileSync(path.join(root,'deneme/ortak/ag/network.js'),'utf8').replace(/\r\n?/g,'\n');s=edit(s,'          x = null,','          x = null,\n          tlsTask = null,');s=edit(s,'              if (x) x.abort();','              if (x) x.abort();\n              if (tlsTask) tlsTask.cancel();');s=edit(s,'        if (\n          !forceXHR &&',[
"        if (root.FilmNativeTLS && root.FilmNativeTLS.supported() && root.FilmNativeTLS.allowed(url)) {",
"          tlsTask = root.FilmNativeTLS.request(url, referer || '', { method: postBody === undefined ? 'GET' : 'POST', body: postBody || '', headers: extraHeaders || {}, timeoutMs: ms, deadline: policy && policy.deadline, byteLimit: LIMIT });",
"          tlsTask.promise.then(function (r) { validate(r.body, 'NativeTLS'); }, finish);",
"          return;",
"        }",
"        if (",
"          !forceXHR &&"].join('\n'));return s;};
exports.media=()=>{let s=fs.readFileSync(path.join(root,'deneme/ortak/ag/media-network.js'),'utf8').replace(/\r\n?/g,'\n');s=edit(s,"      else if (options.only === 'native') attempts = [nativeMode];","      else if (options.only === 'native') attempts = [nativeMode];\n      if (options.only !== 'xhr' && root.FilmNativeTLS && root.FilmNativeTLS.supported() && root.FilmNativeTLS.allowed(url)) attempts.unshift({ method: 'tls' });");s=edit(s,"            mode.method === 'xhr'\n              ? 'XHR", "            mode.method === 'tls'\n              ? 'Native TLS'\n              : mode.method === 'xhr'\n              ? 'XHR");s=edit(s,"            mode.method === 'xhr'\n              ? xhrRequest",[
"            mode.method === 'tls'",
"              ? root.FilmNativeTLS.request(url, options.referer || '', { kind: options.kind, binary: options.binary, timeoutMs: timeout, firstByteTimeoutMs: options.firstByteTimeoutMs, byteLimit: options.byteLimit, rangeStart: options.rangeStart, rangeEnd: options.rangeEnd, deadline: deadline, onprogress: progress })",
"              : mode.method === 'xhr'",
"              ? xhrRequest"].join('\n'));return s;};
